# AgentENV 原生 StorageProvider 内部协议

当前原生接入使用 `agentenv.storage.v2` 请求关联、独立 StorageProvider 和 Pod loopback token。Gateway/Scheduler 保留原 API；完整签名 dispatch 随原创建请求传入。`customExtensionParams` 不承载新存储计划，旧原型协议仍在旧代码中等待安全替代后移除。

## 原创建与设备接入

`POST /storage/admit` 验证 Scheduler 签名、原 body digest、节点/boot、owner/run 和资源预留，返回本次运行的 StorageContext。ticket 不进入模板。没有 SSF 卷时，`managed_mounts` 和 `devices` 仍是 JSON `[]`，不能是 `null`。

`POST http://127.0.0.1:9445/storage/prepare` 使用独立 Bearer token。请求为 `RuntimeEvent`：sequence、ticket、native sandbox_id、不可复用 instance_id、owner_pid/owner_start、boot_id、event=prepare。Provider 必须已准备完整设备计划且 ticket 未被撤销。响应包含原生 CPU/内存资源和 BlockDevice 描述（路径、major/minor、容量、UUID、guest 路径、只读标志）。

`POST /storage/event` 复用事件结构。基本顺序为 prepare → launching → starting(pid/starttime) → ready(devices) → stopped。原生先写日志、fsync、rename、fsync 目录，再发送通知。同序号不同内容冲突，小序号不能覆盖新记录，stopped 后不能复活。

launching 在 spawn 前持久化；starting 在 spawn 后、启动或恢复 VM 前登记。ready 必须经过 guest 容量/UUID/ext4/只读验证。stopped 在 VMM 退出后写入；缺少 PID 的 launching 是未知结果，不能产生停止证明。

`/storage/control` 支持 pause、cancel_pause、resume、delete、cancel_unstarted 及内部 capture。删除先写原生持久任务，再请求 provider；任务本身不是停止证明。暂停保留 owner 的 UseHold，恢复使用新 run/epoch，并要求原运行停止。

## 联合捕获屏障

内部捕获在基本事件流中增加 `ready → capturing → thawing → ready`。`capturing` 携带 `{barrier_id,artifact,digest}`，由可信原生运行时在文件系统冻结、VMM 暂停和 native 捕获完成后写入。字段不含 host 路径或 CSI 参数。digest 关联 native 配置描述和 VM state；它不宣称逐字节校验整个内存/rootfs 数据集。

原生将冻结的 guest 路径和设备身份写入暂停配置及快照 manifest。恢复后必须先核对设备、thaw，再做挂载初始化和 Ready。未知冻结结果不能发布为可运行捕获。恢复 vCPU 前先持久化 thawing，以便控制面拒绝旧屏障证据。

`/storage/control` 的 capture 请求经原 Scheduler 调用公共 `consume.Checkpoints.Advance`。公共模块只创建原生 VolumeSnapshot；每个 Snapshot/Content 的首次 UID 被持久固定，部分结果立即 pin。所有成员 Ready 且屏障再次核验后，才将 CheckpointSet 提交为 Ready。未完成返回 `{ready:false}`，原生保持屏障继续轮询。普通成功响应包含版本化、无 ticket 的 checkpoint 描述。

mTLS `/v1/capture/evidence` 验证 owner/run、binding epoch、PVC/volume 身份、native artifact/digest、当前原生日志和真实 VMM 设备 FD。它不能由普通调用方提供一个布尔值替代。此机制信任原生运行时对冻结和 VMM pause 的操作记录；NodePlugin 不调用公开沙箱 API，也不成为 VMM 生命周期所有者。

RPC 超时不能证明捕获未提交。原生保留 `native-capture.json` 和持久保留标记，普通临时目录及暂停文件 GC 不删除这些内容。共享 `RetainCheckpoint` 可原子建立独立引用，覆盖 native artifact、Snapshot 和 Content。

**当前限制：** 内部代码已连接，但公开 pause/resume/snapshot/Fork 的保护仍保留。模板/Fork 的引用接续、native artifact 自动回收及完整失败恢复尚未接完；带 provider checkpoint 的模板投影/加载会拒绝缺失 clone plan，不能降级为空卷。完整 Linux Rust 类型检查及真实 KVM/CSI 捕获未通过验证，不能将内部协调单测视为完整生命周期验收。

## Ready 与停止证据

NodePlugin 的 mTLS `/v1/evidence` 接受 `{sandbox,action,evidence}`，action 为 ready 或 detached。它重新读取原生记录，并核对 instance、boot、PID namespace、进程 starttime、设备集合及实际块设备 FD；只读设备要求 O_RDONLY。成功返回 204，无法确认返回 409/403。Hook 200、envd health、404 和租约到期都不是停止证据。

同一 ticket 若对应多个 native instance，保留引用并报冲突。节点 drain 拒绝新准入，继续处理真实停止和释放，超时保留不确定引用。

## 原生模板仓库引用与回执

`POST /storage/checkpoints` 使用相同的 loopback 认证；`publish` 在仓库提交前建立独立 CheckpointSet 引用，`delete_begin` 在原生删除前登记删除意图。发布结果未知时保持 Publishing，不能凭模板查询不到就释放引用。原生在写入仓库之前持久化 published 观察任务，在删除之前持久化 deleted 观察任务；任务不是成功证据。

发布、删除和回执都必须携带 `repository_id`。POSIX 仓库在目录内持久化随机 UUID 并计算摘要；OSS 仓库使用 endpoint/bucket/prefix 的摘要标识权威目录。本地缓存目录和节点名称不作为仓库身份。相同模板 ID 在不同仓库具有独立引用。

NodePlugin 读取 `/internal/storage/checkpoints/{immutable_id}`，必须得到 HTTP 200、完全匹配的仓库身份及模板 ID，以及显式 exists/committed 字段。发布要求存在且已提交；删除要求明确不存在。404、认证失败、超时、错误仓库或缺失字段均保留任务和引用。完成事件经原 Scheduler 持久化后才删除 outbox 文件。仓库身份文件损坏时拒绝自动重建，防止绕过已有引用。

模板恢复消费库从快照恢复独立 PVC，包括只读卷，因此删除原卷不破坏模板快照。Fork 消费库维持原只读卷共享语义，可写卷从同一 CheckpointSet 恢复独立 PVC；成员按原设备索引排序。这些消费库仍需完成公开模板/Fork 路径接入和真实运行验收。


### Native child and background admission

`POST /storage/control` with `action=fork` carries the parent ticket, native-generated `child_id`, and opaque joint checkpoint. The plugin fixes the parent's placement and returns a fresh owner/run/request/ticket. Its signed dispatch binds `expected_native_id`; a different VMM ID is rejected even on the first prepare event. Original Orchestrator owns VMM construction and returns partial child results.

`POST /storage/compute` carries `native_id`, `{cpu,memory_mib}` resources and an optional opaque checkpoint. It is authenticated Pod loopback only, and reserves capacity for native builders/recorders through the same admission implementation. The internal Scheduler action is `compute`; it is not a public sandbox API. A recorder restores checkpoint volumes independently and never inherits the source ticket. Native temporary-task cleanup is fsynced before transport and cannot substitute for stopped evidence.

Local paused/capture configs now carry the captured machine resources. Restoring them must compare those actual resources against the reservation; zero/default resource substitution is rejected. Legacy volume captures have a separate runtime-only `captured_volumes` manifest field, preserving original physical `attachedDrives` semantics.
